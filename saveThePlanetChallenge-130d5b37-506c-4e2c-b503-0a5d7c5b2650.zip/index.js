/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';

const Alexa = require('alexa-sdk');

const APP_ID = 'amzn1.ask.skill.c8fb4b1d-406e-4a57-86c7-d833fedc7489';

const languageStrings = {
    'en-GB': {
       translation: {
            CHALLENGES: [
                'I challenge you to check the light bulbs in your home to see if they are energy saving bulbs. If any are not, then replace them.',
                'I challenge you to wash your clothes on the cold cycle. Do not worry, modern detergents will be able to handle it.',
                'I challenge you to stop using the dryer and start drying your clothes on a clothes line or drying rack.',
                'I challenge you to start taking shorter showers.',
                'I challenge you to switch your shower heads to low flow shower heads',
                'I challenge you to plant a tree. If you do not have a garden then get a house plant instead',
                'I challenge you to eat a meatless meal this week',
                'I challenge you to switch from bottled water to a reusable container',
                'I challenge you to donate or recycle any old electronics you have at home',
                'I challenge you to make your own cleaning product. Try some baking soda, vinegar, and lemon. Or find some ideas online.',
                'I challenge you to make sure your TV picture is set to normal or standard instead of vivid.',
                'I challenge you to make sure your TV, games consoles and streaming devices are set to automatically power off after inactivity',
                'I challenge you to make sure your laptop or computer is set to hibernate after inactivity. You can also make the screen turn off for shorter periods of inactivity.',
                'I challenge you to use reusable bags next time you go shopping for food',
                'I challenge you to use a reusble cup next time you go to get a coffee',
                'I challenge you to make sure you turn off all the lights whenever you leave an empty room',
                'I challenge you to see if you can recycle any more of your trash than you currently do',
                'I challenge you to unplug any phone, laptop, or other electronic appliance chargers when you are not using them.',
                'I challenge you to use the half flush on your toilet, if possible',
                'I challenge you to make sure that all your bills are set to be electronic bills rather than paper bills',
                'I challenge you to avoid plastic straws or coffee stirrers when you buy drinks',
                'I challenge you to make a donation to an environmental organization',
            ],
            SKILL_NAME: 'Save the Planet Challenge',
            GET_CHALLENGE_MESSAGE: "Here's your next challenge: ",
            HELP_MESSAGE: 'You can say give me a new challenge, or, you can say exit... What can I help you with?',
            HELP_REPROMPT: 'What can I help you with?',
            STOP_MESSAGE: 'Goodbye!',
        },
    },
    'en-US': {
        translation: {
            CHALLENGES: [
                'I challenge you to check the light bulbs in your home to see if they are energy saving bulbs. If any are not, then replace them.',
                'I challenge you to wash your clothes on the cold cycle. Do not worry, modern detergents will be able to handle it.',
                'I challenge you to stop using the dryer and start drying your clothes on a clothes line or drying rack.',
                'I challenge you to start taking shorter showers.',
                'I challenge you to switch your shower heads to low flow shower heads',
                'I challenge you to plant a tree. If you do not have a garden then get a house plant instead',
                'I challenge you to eat a meatless meal this week',
                'I challenge you to switch from bottled water to a reusable container',
                'I challenge you to donate or recycle any old electronics you have at home',
                'I challenge you to make your own cleaning product. Try some baking soda, vinegar, and lemon. Or find some ideas online.',
                'I challenge you to make sure your TV picture is set to normal or standard instead of vivid.',
                'I challenge you to make sure your TV, games consoles and streaming devices are set to automatically power off after inactivity',
                'I challenge you to make sure your laptop or computer is set to hibernate after inactivity. You can also make the screen turn off for shorter periods of inactivity.',
                'I challenge you to use reusable bags next time you go shopping for food',
                'I challenge you to use a reusble cup next time you go to get a coffee',
                'I challenge you to make sure you turn off all the lights whenever you leave an empty room',
                'I challenge you to see if you can recycle any more of your trash than you currently do',
                'I challenge you to unplug any phone, laptop, or other electronic appliance chargers when you are not using them.',
                'I challenge you to use the half flush on your toilet, if possible',
                'I challenge you to make sure that all your bills are set to be electronic bills rather than paper bills',
                'I challenge you to avoid plastic straws or coffee stirrers when you buy drinks',
                'I challenge you to make a donation to an environmental organization',
            ],
            SKILL_NAME: 'Save the Planet Challenge',
            GET_CHALLENGE_MESSAGE: "Here's your next challenge: ",
            HELP_MESSAGE: 'You can say give me a new challenge, or, you can say exit... What can I help you with?',
            HELP_REPROMPT: 'What can I help you with?',
            STOP_MESSAGE: 'Goodbye!',
        },
    },
};

const handlers = {
    'LaunchRequest': function () {
        this.emit('GetChallenge');
    },
    'GetNewChallengeIntent': function () {
        this.emit('GetChallenge');
    },
    'GetChallenge': function () {
        // Get a random Challenge from the CHALLENGES list
        // Use this.t() to get corresponding language data
        const challengeArr = this.t('CHALLENGES');
        const challengeIndex = Math.floor(Math.random() * challengeArr.length);
        const randomChallenge = challengeArr[challengeIndex];

        // Create speech output
        const speechOutput = this.t('GET_CHALLENGE_MESSAGE') + randomChallenge;
        this.emit(':tellWithCard', speechOutput, this.t('SKILL_NAME'), randomChallenge);
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = this.t('HELP_MESSAGE');
        const reprompt = this.t('HELP_MESSAGE');
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'SessionEndedRequest': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
};

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
